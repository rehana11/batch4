$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/feature/testcase.feature");
formatter.feature({
  "line": 3,
  "name": "taskmanager website",
  "description": "",
  "id": "taskmanager-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@taskmanager"
    }
  ]
});
formatter.scenarioOutline({
  "line": 6,
  "name": "Login to the TaskManager",
  "description": "",
  "id": "taskmanager-website;login-to-the-taskmanager",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@tc_01_login"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "Open the  taskmanager website  Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "enter the \"\u003cusername1\u003e\" and \"\u003cpassword1\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "click on Login button",
  "keyword": "And "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "taskmanager-website;login-to-the-taskmanager;",
  "rows": [
    {
      "cells": [
        "username1",
        "password1"
      ],
      "line": 14,
      "id": "taskmanager-website;login-to-the-taskmanager;;1"
    },
    {
      "cells": [
        "admin",
        "admin"
      ],
      "line": 15,
      "id": "taskmanager-website;login-to-the-taskmanager;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "Login to the TaskManager",
  "description": "",
  "id": "taskmanager-website;login-to-the-taskmanager;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@tc_01_login"
    },
    {
      "line": 1,
      "name": "@taskmanager"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "Open the  taskmanager website  Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "enter the \"admin\" and \"admin\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "click on Login button",
  "keyword": "And "
});
formatter.match({
  "location": "taskmanagerloginstep.launch_the_browser()"
});
formatter.result({
  "duration": 9150275681,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 11
    },
    {
      "val": "admin",
      "offset": 23
    }
  ],
  "location": "taskmanagerloginstep.enter_Username_and_Password(String,String)"
});
formatter.result({
  "duration": 477646883,
  "status": "passed"
});
formatter.match({
  "location": "taskmanagerloginstep.click_on_Login_button()"
});
formatter.result({
  "duration": 3272410593,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Add Project to the TaskManager Website",
  "description": "",
  "id": "taskmanager-website;add-project-to-the-taskmanager-website",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 19,
      "name": "@tc_02_addproject"
    }
  ]
});
formatter.step({
  "line": 22,
  "name": "Open the Website in the Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "click on the administration",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "Click on the Projects",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "Click on the Add New Project",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "Enter the Project Name",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "Click on the Add Button",
  "keyword": "And "
});
formatter.match({
  "location": "Addprojectstep.open_the_Website_in_the_Browser()"
});
formatter.result({
  "duration": 7273116217,
  "status": "passed"
});
formatter.match({
  "location": "Addprojectstep.click_on_the_administration()"
});
formatter.result({
  "duration": 1856112903,
  "status": "passed"
});
formatter.match({
  "location": "Addprojectstep.click_on_the_Projects()"
});
formatter.result({
  "duration": 2926414531,
  "status": "passed"
});
formatter.match({
  "location": "Addprojectstep.click_on_the_Add_New_Project()"
});
formatter.result({
  "duration": 1527165211,
  "status": "passed"
});
formatter.match({
  "location": "Addprojectstep.enter_the_Project_Name()"
});
formatter.result({
  "duration": 430975166,
  "status": "passed"
});
formatter.match({
  "location": "Addprojectstep.click_on_the_Add_Button()"
});
formatter.result({
  "duration": 2087559888,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Search the  New Project",
  "description": "",
  "id": "taskmanager-website;search-the--new-project",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 29,
      "name": "@tc_03_searchproject"
    }
  ]
});
formatter.step({
  "line": 32,
  "name": "Open the website  Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "Click On Task List",
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "Select the Newly Entered Project",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "Click on the Search button",
  "keyword": "And "
});
formatter.match({
  "location": "searchprojectstep.open_the_website_Browser()"
});
formatter.result({
  "duration": 7548685950,
  "status": "passed"
});
formatter.match({
  "location": "searchprojectstep.click_On_Task_List()"
});
formatter.result({
  "duration": 3668354517,
  "status": "passed"
});
formatter.match({
  "location": "searchprojectstep.select_the_Newly_Entered_Project()"
});
formatter.result({
  "duration": 800606272,
  "status": "passed"
});
formatter.match({
  "location": "searchprojectstep.click_on_the_Search_button()"
});
formatter.result({
  "duration": 2411758095,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "Add Task to the  Newly entered Project",
  "description": "",
  "id": "taskmanager-website;add-task-to-the--newly-entered-project",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 37,
      "name": "@tc_04_addtask"
    }
  ]
});
formatter.step({
  "line": 40,
  "name": "Launch the Website in the Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "Click on the AddNewTask",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "Enter all the details",
  "keyword": "Then "
});
formatter.step({
  "line": 43,
  "name": "Click on the Add button",
  "keyword": "And "
});
formatter.match({
  "location": "add_newtask_step.launch_the_Website_in_the_Browser()"
});
formatter.result({
  "duration": 7172865374,
  "status": "passed"
});
formatter.match({
  "location": "add_newtask_step.click_on_the_AddNewTask()"
});
formatter.result({
  "duration": 2407950809,
  "status": "passed"
});
formatter.match({
  "location": "add_newtask_step.enter_all_the_details()"
});
formatter.result({
  "duration": 4987835055,
  "status": "passed"
});
formatter.match({
  "location": "add_newtask_step.click_on_the_Add_button()"
});
formatter.result({
  "duration": 3394257099,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "logout the page",
  "description": "",
  "id": "taskmanager-website;logout-the-page",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 45,
      "name": "@tc_05_logout"
    }
  ]
});
formatter.step({
  "line": 48,
  "name": "Launch the Website Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 49,
  "name": "click administration",
  "keyword": "And "
});
formatter.step({
  "line": 50,
  "name": "click the logout",
  "keyword": "And "
});
formatter.match({
  "location": "logoutstep.Launch_the_Website_Browser()"
});
formatter.result({
  "duration": 9771524331,
  "status": "passed"
});
formatter.match({
  "location": "logoutstep.click_administration()"
});
formatter.result({
  "duration": 724892643,
  "status": "passed"
});
formatter.match({
  "location": "logoutstep.click_the_logout()"
});
formatter.result({
  "duration": 2317508385,
  "status": "passed"
});
});